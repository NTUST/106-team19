from django import forms
from .models import Repairsystem
from .models import Feedback

class RepairsystemForm(forms.ModelForm):
        class Meta:
                model = Repairsystem
                fields = ('applicant','title','place', 'message',)

class FeedbackForm(forms.ModelForm):
        class Meta:
                model = Feedback
                fields = ('author','title','email', 'content',)