# -*- coding: utf-8 -*-
from __future__ import unicode_literals
from django.utils import timezone
from django.shortcuts import render
from django.shortcuts import get_object_or_404,render
from django.http import HttpResponseRedirect
from django.urls import reverse
from .models import Post,Photo,album,Question,Choice
from .models import Repairsystem
from .forms import RepairsystemForm
from django.core.exceptions import ObjectDoesNotExist
from django.utils.timezone import localtime
from django.shortcuts import redirect
from django.shortcuts import render, get_object_or_404
from .models import Feedback
from .forms import FeedbackForm

# Create your views here.
def index(request):
	return render(request, "myblog/index.html")

def information(request):
    posts = Post.objects.filter(published_date__lte=timezone.now()).order_by('published_date')
    return render(request, "myblog/information.html", {'posts': posts})

def activity(request):
	queryset = album.objects.all()
	context = {
		"albums": queryset,
	}
	return render(request, "myblog/activity.html", context)

def photo(request):
	queryset = Photo.objects.all()
	context = {
		"photos": queryset,
	}
	return render(request, "myblog/photo.html", context)

def inquire(request):
	return render(request, "myblog/inquire.html")

def connection(request):
	return render(request, "myblog/connection.html")

def about(request):
	return render(request, "myblog/about.html")

def purchase(request):
	return render(request, "myblog/purchase.html")

def public(request):
	return render(request, "myblog/public.html")

def contact(request):
	return render(request, "myblog/contact.html")



def paticipation(request):
    latest_question_list = Question.objects.order_by('-pub_date')[:5]
    context = {'latest_question_list': latest_question_list}
    return render(request, 'myblog/paticipation.html', context)

def detail(request, question_id):
    question = get_object_or_404(Question, pk=question_id)
    return render(request, 'myblog/detail.html', {'question': question})

def results(request, question_id):
    question = get_object_or_404(Question, pk=question_id)
    return render(request, 'myblog/results.html', {'question': question})

def vote(request, question_id):
    question = get_object_or_404(Question, pk=question_id)
    try:
        selected_choice = question.choice_set.get(pk=request.POST['choice'])
    except (KeyError, Choice.DoesNotExist):
        # Redisplay the question voting form.
        return render(request, 'myblog/detail.html', {
            'question': question,
            'error_message': "You didn't select a choice.",
        })
    else:
        selected_choice.votes += 1
        selected_choice.save()
        # Always return an HttpResponseRedirect after successfully dealing
        # with POST data. This prevents data from being posted twice if a
        # user hits the Back button.
        return HttpResponseRedirect(reverse('myblog:results', args=(question.id,)))

def repairsystem_list(request):
    repairsystems = Repairsystem.objects.filter(published_date__lte=timezone.now()).order_by('published_date')
    return render(request, 'myblog/post_list.html',{'repairsystems':repairsystems})

def repairsystem_add(request):
        if request.method == 'POST':
                form = RepairsystemForm(request.POST)
                if form.is_valid():
                        repairsystem = form.save(commit=False)
                        
                        repairsystem.published_date = timezone.now()
                        repairsystem.save()
                        return redirect('repairsystem_list')
        else:
                form = RepairsystemForm()
        return render(request, 'myblog/form.html',{'form': form})

def repairsystem_edit(request, pk):
    repairsystem = get_object_or_404(Repairsystem, pk=pk)
    if request.method == "POST":
        form = RepairsystemForm(request.POST, instance=repairsystem)
        if form.is_valid():
            repairsystem = form.save(commit=False)
            
            repairsystem.published_date = timezone.now()
            repairsystem.save()
            return redirect('repairsystem_list')
    else:
        form = RepairsystemForm(instance=repairsystem)
    return render(request, 'myblog/form.html', {'form': form})       


def feedback_list(request):
    feedbacks = Feedback.objects.filter(published_date__lte=timezone.now()).order_by('published_date')
    return render(request, 'myblog/post_list2.html',{'feedbacks':feedbacks})

def feedback_add(request):
        if request.method == 'POST':
                form = FeedbackForm(request.POST)
                if form.is_valid():
                        feedback = form.save(commit=False)
                        
                        feedback.published_date = timezone.now()
                        feedback.save()
                        return redirect('feedback_list')
        else:
                form = FeedbackForm()
        return render(request, 'myblog/form2.html',{'form': form})

def feedback_edit(request, pk):
    feedback = get_object_or_404(Feedback, pk=pk)
    if request.method == "POST":
        form = FeedbackForm(request.POST, instance=feedback)
        if form.is_valid():
            feedback = form.save(commit=False)
            
            feedback.published_date = timezone.now()
            feedback.save()
            return redirect('feedback_list')
    else:
        form = FeedbackForm(instance=feedback)
    return render(request, 'myblog/form2.html', {'form': form})       