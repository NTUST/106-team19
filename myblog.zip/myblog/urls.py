from django.conf.urls import url
from . import views

urlpatterns = [
    url(r'^$', views.index, name='index'),
    url(r'^information/$', views.information, name='information'),
    url(r'^connection/$', views.connection, name='connection'),
    url(r'^about/$', views.about, name='about'),
    url(r'^activity/$', views.activity, name='activity'),
    url(r'^photo/$', views.photo, name='photo'),
    url(r'^inquire/$', views.inquire, name='inquire'),
    url(r'^purchase/$', views.purchase, name='purchase'),
    url(r'^public/$', views.public, name='public'),
    url(r'^contact/$', views.contact, name='contact'),
    url(r'^paticipation/$', views.paticipation, name='paticipation'),
    url(r'^(?P<question_id>[0-9]+)/detail/$', views.detail, name='detail'),
    url(r'^(?P<question_id>[0-9]+)/results/$', views.results, name='results'),
    url(r'^(?P<question_id>[0-9]+)/vote/$', views.vote, name='vote'),
    url(r'^repairsystem/$', views.repairsystem_list, name='repairsystem_list'), 
    url(r'^repairsystem/add/$', views.repairsystem_add, name='repairsystem_add'),
    url(r'^repairsystem/(?P<pk>[0-9]+)/edit/$', views.repairsystem_edit, name='repairsystem_edit'),
    url(r'^feedback/$', views.feedback_list, name='feedback_list'),  
    url(r'^feedback/add/$', views.feedback_add, name='feedback_add'),
    url(r'^feedback/(?P<pk>[0-9]+)/edit/$', views.feedback_edit, name='feedback_edit'),
]